var init = function (window) {
    'use strict';
    var 
        draw = window.opspark.draw,
        physikz = window.opspark.racket.physikz,
        
        app = window.opspark.makeApp(),
        canvas = app.canvas, 
        view = app.view,
        fps = draw.fps('#000');
        
    
    window.opspark.makeRunner = function() {
        
    window.opspark.runner = {};
    var runner = window.opspark.runner;
        
    var circle;
    var circles = [];

    var drawCircle;
    var drawCircle = function() {
    circle = draw.randomCircleInArea(canvas, true, true, '#999', 2);
    physikz.addRandomVelocity(circle, canvas);
    view.addChild(circle);
    circles.push(circle);
    }
    
    var counter = 0; 
    while (counter < 10) {
    counter++
    }

    for (var counter = 0; counter < 10; counter++) {
    }
    
    view.addChild(fps);
    app.addUpdateable(fps);
    
    runner.checkCircleBounds = function(Drawcircle);
    
    if ( circle.x > canvas.width + circle.radius ) {
    circle.x = 0 - circle.radius;
    } 
    
    else if ( circle.x< canvas.width + circle.radius ) {
    circle.x = 0 + circle.radius;          
    } 
    
    if ( circle.y > canvas.height + circle.radius ) {
    circle.y = 0 - circle.radius;            
    }
    
    else if ( circle.y < canvas.height + circle.radius ) {
    circle.y = 0 -circle.radius;       
    }
    
    var update = function(runner.checkCircleBounds) {
    physikz.updatePosition(circles[0]);
    physikz.updatePosition(circles[1]);
    physikz.updatePosition(circles[2]);
    physikz.updatePosition(circles[3]);
    physikz.updatePosition(circles[4]);
    }
    
    var circle;
    var circles = [0, 1, 2, 3, 4];
    for (var circle = 0; i < circles.length; i++) {
    circle = circle[0];
    console.log(circle);
    }

    var circles = 0;
    while (circle < circles.length) {
    circle = circles[0];
    console.log(circle);
    i++;
    }
    
    runner.circle = circle;
    runner.circles = circles;
    runner.drawCircle = drawCircle;
    runner.update = update;
    app.addUpdateable(window.opspark.runner);
    }
};
if((typeof process !== 'undefined') &&
    (typeof process.versions.node !== 'undefined')) {
   
    module.exports = init;
}